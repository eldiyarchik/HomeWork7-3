package com.agn.homework7m3

class UsersModel(
    var name: String,
    var age: Int,
    var img: Int
)
